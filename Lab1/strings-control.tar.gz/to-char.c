#include <stdio.h>
#include <string.h>

const int STRLEN = 1024;

int main(void)
{
    int base = 0;
    char coded_message[STRLEN] = {};
    char translated_message[STRLEN] = {};

    printf("\nEnter a base to translate (8, 10, 16): ");
    scanf("%d", &base);
    while (getchar() != '\n');

    if (base != 8 && base != 10 && base !=16)
    {
        printf("\nINVALID BASE, TERMINATING PROGRAM.\n");
        return 0;
    }

    if (base == 8)
    {

    }

    if (base == 10)
    {

    }
    if (base == 16)
    {

    }

    printf("\ntranslated message: %s", translated_message);
    return 1;
}
