#include <stdio.h>

//gcc -Wall -o hello hello.c
//./hello

int main(void)
{
    printf("Hello cs205\n");
    return 0;
}
